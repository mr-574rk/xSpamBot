<h1>xSpamBot</h1>
<p><a href="https://github.com/mr-574rk/xSpamBot"><img  style="max-width:100%;"></a>
<a href="https://github.com/mr-574rk/xSpamBot"><img src="https://img.shields.io/badge/Release-Stable-orange.svg" alt="Stage" data-canonical-src="https://img.shields.io/badge/Release-Stable-orange.svg" style="max-width:100%;"></a>
<a href="https://github.com/mr-574rk/xSpamBot"><img src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" alt="Build" data-canonical-src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" style="max-width:100%;"></a></p>
<p><h1>Auto report Instagram accounts ( SPAM BOT ) 😈 </h1>
<br> ⚠️Note! : We don't Accept any responsibility for any illegal usage.</p>

<h2>xSpamBot</h2>


<h2>Usage</h2>

<h2>Example</h2>
<p>run the tool with this command<p>
<code>python3 bot.py</code>
